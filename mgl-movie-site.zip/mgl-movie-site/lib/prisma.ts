import { PrismaClient } from '@prisma/client';

// Next.js dev горимд hot-reload үед олон PrismaClient instance үүсэхээс сэргийлнэ
const globalForPrisma = global as unknown as { prisma: PrismaClient };

export const prisma =
  globalForPrisma.prisma ||
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['error', 'warn'] : ['error']
  });

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma;

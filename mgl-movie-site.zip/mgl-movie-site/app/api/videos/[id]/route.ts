import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { unlink } from 'fs/promises';
import path from 'path';

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const video = await prisma.video.findUnique({
    where: { id: params.id },
    include: { owner: { select: { name: true, id: true } } }
  });

  if (!video) {
    return NextResponse.json({ error: 'Видео олдсонгүй' }, { status: 404 });
  }

  if (video.visibility === 'PRIVATE') {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    if (!session?.user || userId !== video.ownerId) {
      return NextResponse.json({ error: 'Энэ видеог үзэх эрхгүй байна' }, { status: 403 });
    }
  }

  return NextResponse.json(video);
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as { id?: string } | undefined)?.id;
  if (!userId) {
    return NextResponse.json({ error: 'Нэвтэрнэ үү' }, { status: 401 });
  }

  const video = await prisma.video.findUnique({ where: { id: params.id } });
  if (!video) {
    return NextResponse.json({ error: 'Видео олдсонгүй' }, { status: 404 });
  }
  if (video.ownerId !== userId) {
    return NextResponse.json({ error: 'Энэ видеог устгах эрхгүй байна' }, { status: 403 });
  }

  await prisma.video.delete({ where: { id: params.id } });

  try {
    await unlink(path.join(process.cwd(), 'public', video.filePath));
  } catch {
    // Файл аль хэдийн байхгүй бол алгасна
  }

  return NextResponse.json({ ok: true });
}

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { writeFile, mkdir } from 'fs/promises';
import path from 'path';
import crypto from 'crypto';

const UPLOAD_DIR = path.join(process.cwd(), 'public', 'uploads', 'videos');
const ALLOWED_TYPES = ['video/mp4', 'video/webm', 'video/quicktime', 'video/x-matroska'];
const MAX_SIZE_BYTES = Number(process.env.MAX_UPLOAD_SIZE_MB || 500) * 1024 * 1024;

// GET /api/videos            -> нийтэд нээлттэй бүх видео
// GET /api/videos?mine=true  -> нэвтэрсэн хэрэглэгчийн видео (private-г оролцуулна)
export async function GET(req: NextRequest) {
  const mine = req.nextUrl.searchParams.get('mine') === 'true';

  if (mine) {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Нэвтэрнэ үү' }, { status: 401 });
    }
    const videos = await prisma.video.findMany({
      where: { ownerId: (session.user as { id: string }).id },
      orderBy: { createdAt: 'desc' }
    });
    return NextResponse.json(videos);
  }

  const videos = await prisma.video.findMany({
    where: { visibility: 'PUBLIC' },
    orderBy: { createdAt: 'desc' },
    include: { owner: { select: { name: true } } }
  });
  return NextResponse.json(videos);
}

// POST /api/videos  (multipart/form-data: title, description, visibility, file)
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: 'Нэвтэрнэ үү' }, { status: 401 });
  }

  const formData = await req.formData();
  const title = (formData.get('title') as string | null)?.trim();
  const description = (formData.get('description') as string | null)?.trim() || '';
  const visibility = formData.get('visibility') === 'PUBLIC' ? 'PUBLIC' : 'PRIVATE';
  const file = formData.get('file') as File | null;

  if (!title) {
    return NextResponse.json({ error: 'Гарчиг оруулна уу' }, { status: 400 });
  }
  if (!file) {
    return NextResponse.json({ error: 'Видео файл сонгоно уу' }, { status: 400 });
  }
  if (!ALLOWED_TYPES.includes(file.type)) {
    return NextResponse.json(
      { error: 'Зөвшөөрөгдөөгүй файлын төрөл. mp4, webm, mov, mkv ашиглана уу' },
      { status: 400 }
    );
  }
  if (file.size > MAX_SIZE_BYTES) {
    return NextResponse.json(
      { error: `Файлын хэмжээ хэт том байна (дээд тал нь ${MAX_SIZE_BYTES / 1024 / 1024}MB)` },
      { status: 400 }
    );
  }

  await mkdir(UPLOAD_DIR, { recursive: true });

  const ext = path.extname(file.name) || '.mp4';
  const uniqueName = `${crypto.randomUUID()}${ext}`;
  const destPath = path.join(UPLOAD_DIR, uniqueName);

  const bytes = Buffer.from(await file.arrayBuffer());
  await writeFile(destPath, bytes);

  const video = await prisma.video.create({
    data: {
      title,
      description,
      visibility,
      filePath: `/uploads/videos/${uniqueName}`,
      ownerId: (session.user as { id: string }).id
    }
  });

  return NextResponse.json(video, { status: 201 });
}

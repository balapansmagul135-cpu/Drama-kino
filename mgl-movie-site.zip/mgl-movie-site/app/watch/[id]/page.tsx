import { getServerSession } from 'next-auth';
import { notFound } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import DeleteButton from './DeleteButton';

export const dynamic = 'force-dynamic';

export default async function WatchPage({ params }: { params: { id: string } }) {
  const video = await prisma.video.findUnique({
    where: { id: params.id },
    include: { owner: { select: { id: true, name: true } } }
  });

  if (!video) {
    notFound();
  }

  const session = await getServerSession(authOptions);
  const userId = (session?.user as { id?: string } | undefined)?.id;
  const isOwner = userId === video.ownerId;

  if (video.visibility === 'PRIVATE' && !isOwner) {
    notFound();
  }

  return (
    <div className="container watch-shell">
      <div className="player-wrap">
        <video src={video.filePath} controls preload="metadata" />
      </div>

      <h1 className="watch-title">{video.title}</h1>
      <div className="watch-meta">
        {video.owner.name} · {new Date(video.createdAt).toLocaleDateString('mn-MN')} ·{' '}
        {video.visibility === 'PUBLIC' ? 'Нийтэд нээлттэй' : 'Хувийн'}
      </div>

      {video.description && <p className="watch-desc">{video.description}</p>}

      {isOwner && (
        <div style={{ marginTop: 24 }}>
          <DeleteButton videoId={video.id} />
        </div>
      )}
    </div>
  );
}

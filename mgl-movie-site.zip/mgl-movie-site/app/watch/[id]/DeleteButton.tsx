'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function DeleteButton({ videoId }: { videoId: string }) {
  const router = useRouter();
  const [confirming, setConfirming] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleDelete() {
    setLoading(true);
    const res = await fetch(`/api/videos/${videoId}`, { method: 'DELETE' });
    setLoading(false);

    if (res.ok) {
      router.push('/my-movies');
      router.refresh();
    }
  }

  if (!confirming) {
    return (
      <button className="btn btn-outline" onClick={() => setConfirming(true)}>
        Устгах
      </button>
    );
  }

  return (
    <div className="btn-row">
      <button className="btn btn-primary" onClick={handleDelete} disabled={loading}>
        {loading ? 'Устгаж байна…' : 'Тийм, устгах'}
      </button>
      <button className="btn btn-outline" onClick={() => setConfirming(false)}>
        Цуцлах
      </button>
    </div>
  );
}

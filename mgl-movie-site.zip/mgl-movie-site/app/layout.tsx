import type { Metadata } from 'next';
import './globals.css';
import Providers from '@/components/Providers';
import Navbar from '@/components/Navbar';

export const metadata: Metadata = {
  title: 'MGL Movie — Өөрийн кино контентоо байршуул',
  description: 'Кино, драмын контентоо байршуулж, хуваалцах платформ'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="mn">
      <body>
        <Providers>
          <Navbar />
          <main>{children}</main>
          <footer className="footer">
            <div className="container">
              © {new Date().getFullYear()} MGL Movie. Бүх эрх хуулиар хамгаалагдсан.
            </div>
          </footer>
        </Providers>
      </body>
    </html>
  );
}

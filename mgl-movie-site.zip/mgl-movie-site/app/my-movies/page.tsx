import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import VideoCard from '@/components/VideoCard';

export const dynamic = 'force-dynamic';

export default async function MyMoviesPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    redirect('/login');
  }

  const userId = (session.user as { id: string }).id;

  const videos = await prisma.video.findMany({
    where: { ownerId: userId },
    orderBy: { createdAt: 'desc' }
  });

  return (
    <section className="section">
      <div className="container">
        <div className="section-head">
          <h2>Миний кино</h2>
          <span>{videos.length} видео</span>
        </div>

        {videos.length === 0 ? (
          <div className="empty-state">
            <h3>Та одоогоор видео байршуулаагүй байна</h3>
            <p style={{ marginBottom: 20 }}>Эхний видеогоо байршуулж эхлээрэй.</p>
            <Link href="/upload" className="btn btn-primary">
              Кино байршуулах
            </Link>
          </div>
        ) : (
          <div className="poster-grid">
            {videos.map((v) => (
              <VideoCard
                key={v.id}
                id={v.id}
                title={v.title}
                visibility={v.visibility}
                createdAt={v.createdAt.toISOString()}
                showBadge
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

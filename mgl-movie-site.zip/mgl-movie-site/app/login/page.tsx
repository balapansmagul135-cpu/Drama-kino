'use client';

import { useState, FormEvent } from 'react';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);

    const res = await signIn('credentials', {
      email,
      password,
      redirect: false
    });

    setLoading(false);

    if (res?.error) {
      setError('Имэйл эсвэл нууц үг буруу байна');
      return;
    }

    router.push('/my-movies');
    router.refresh();
  }

  return (
    <div className="auth-shell">
      <div className="auth-card">
        <h1>Нэвтрэх</h1>
        <p className="sub">Кино контентоо удирдахын тулд бүртгэлдээ нэвтэрнэ үү</p>

        {error && <div className="form-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="email">Имэйл хаяг</label>
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="tanii@imeil.mn"
            />
          </div>

          <div className="field">
            <label htmlFor="password">Нууц үг</label>
            <input
              id="password"
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </div>

          <button className="btn btn-primary btn-block" type="submit" disabled={loading}>
            {loading ? 'Нэвтэрч байна…' : 'Нэвтрэх'}
          </button>
        </form>

        <div className="form-hint">
          Бүртгэлгүй юу? <Link href="/register">Шинээр бүртгүүлэх</Link>
        </div>
      </div>
    </div>
  );
}

import Link from 'next/link';
import { prisma } from '@/lib/prisma';
import VideoCard from '@/components/VideoCard';

export const dynamic = 'force-dynamic';

export default async function HomePage() {
  const videos = await prisma.video.findMany({
    where: { visibility: 'PUBLIC' },
    orderBy: { createdAt: 'desc' },
    take: 24,
    include: { owner: { select: { name: true } } }
  });

  return (
    <>
      <section className="hero">
        <div className="container">
          <div className="hero-eyebrow">Өөрийн кино, драмаа хуваалц</div>
          <h1>Кино контентоо байршуулж, харагчидтайгаа шууд холбогдо</h1>
          <p>
            MGL Movie бол киноны бүтээгчид, контент бүтээгчдэд зориулсан платформ. Видеогоо
            байршуулж, хувийн эсвэл нийтэд нээлттэй болгон хадгал.
          </p>
          <div className="btn-row">
            <Link href="/upload" className="btn btn-primary">
              Кино байршуулах
            </Link>
            <Link href="#latest" className="btn btn-outline">
              Кинонууд үзэх
            </Link>
          </div>
        </div>
      </section>

      <section className="section" id="latest">
        <div className="container">
          <div className="section-head">
            <h2>Шинээр нэмэгдсэн</h2>
            <span>{videos.length} кино</span>
          </div>

          {videos.length === 0 ? (
            <div className="empty-state">
              <h3>Одоогоор нийтэд нээлттэй видео алга</h3>
              <p>Анхны видеогоо байршуулаад энд харуулаарай.</p>
            </div>
          ) : (
            <div className="poster-grid">
              {videos.map((v) => (
                <VideoCard
                  key={v.id}
                  id={v.id}
                  title={v.title}
                  visibility={v.visibility}
                  createdAt={v.createdAt.toISOString()}
                  ownerName={v.owner?.name}
                />
              ))}
            </div>
          )}
        </div>
      </section>
    </>
  );
}

'use client';

import { useState, FormEvent } from 'react';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function RegisterPage() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);

    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password })
    });

    const data = await res.json();

    if (!res.ok) {
      setError(data.error || 'Алдаа гарлаа');
      setLoading(false);
      return;
    }

    const signInRes = await signIn('credentials', { email, password, redirect: false });
    setLoading(false);

    if (signInRes?.error) {
      router.push('/login');
      return;
    }

    router.push('/my-movies');
    router.refresh();
  }

  return (
    <div className="auth-shell">
      <div className="auth-card">
        <h1>Шинээр бүртгүүлэх</h1>
        <p className="sub">Кино контентоо байршуулж эхлэхийн тулд бүртгэл үүсгэнэ үү</p>

        {error && <div className="form-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="name">Нэр</label>
            <input
              id="name"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Таны нэр"
            />
          </div>

          <div className="field">
            <label htmlFor="email">Имэйл хаяг</label>
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="tanii@imeil.mn"
            />
          </div>

          <div className="field">
            <label htmlFor="password">Нууц үг</label>
            <input
              id="password"
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Хамгийн багадаа 6 тэмдэгт"
            />
          </div>

          <button className="btn btn-primary btn-block" type="submit" disabled={loading}>
            {loading ? 'Бүртгэж байна…' : 'Бүртгүүлэх'}
          </button>
        </form>

        <div className="form-hint">
          Бүртгэлтэй юу? <Link href="/login">Нэвтрэх</Link>
        </div>
      </div>
    </div>
  );
}

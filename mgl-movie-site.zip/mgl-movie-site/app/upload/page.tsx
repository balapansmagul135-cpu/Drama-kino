'use client';

import { useState, FormEvent, useRef } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';

export default function UploadPage() {
  const { status } = useSession();
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [visibility, setVisibility] = useState<'PRIVATE' | 'PUBLIC'>('PRIVATE');
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState('');
  const [progress, setProgress] = useState(0);
  const [uploading, setUploading] = useState(false);

  if (status === 'unauthenticated') {
    router.push('/login');
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');

    if (!file) {
      setError('Видео файл сонгоно уу');
      return;
    }

    const formData = new FormData();
    formData.append('title', title);
    formData.append('description', description);
    formData.append('visibility', visibility);
    formData.append('file', file);

    setUploading(true);
    setProgress(0);

    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/videos');

    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable) {
        setProgress(Math.round((event.loaded / event.total) * 100));
      }
    };

    xhr.onload = () => {
      setUploading(false);
      if (xhr.status === 201) {
        const video = JSON.parse(xhr.responseText);
        router.push(`/watch/${video.id}`);
      } else {
        try {
          const data = JSON.parse(xhr.responseText);
          setError(data.error || 'Байршуулахад алдаа гарлаа');
        } catch {
          setError('Байршуулахад алдаа гарлаа');
        }
      }
    };

    xhr.onerror = () => {
      setUploading(false);
      setError('Сүлжээний алдаа гарлаа');
    };

    xhr.send(formData);
  }

  return (
    <div className="container">
      <div className="upload-shell">
        <h1>Кино байршуулах</h1>
        <p className="sub">Видео файл, гарчиг болон тайлбараа оруулна уу</p>

        {error && <div className="form-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="title">Гарчиг</label>
            <input
              id="title"
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Кино/драмын нэр"
            />
          </div>

          <div className="field">
            <label htmlFor="description">Тайлбар</label>
            <textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Товч агуулга (сонголтоор)"
            />
          </div>

          <div className="field">
            <label>Файл</label>
            <div
              className={`file-drop ${file ? 'has-file' : ''}`}
              onClick={() => fileInputRef.current?.click()}
            >
              {file ? file.name : 'Видео файл сонгохын тулд энд дарна уу (mp4, webm, mov, mkv)'}
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="video/mp4,video/webm,video/quicktime,video/x-matroska"
              style={{ display: 'none' }}
              onChange={(e) => setFile(e.target.files?.[0] || null)}
            />
          </div>

          <div className="field">
            <label>Харагдах байдал</label>
            <div className="radio-row">
              <div
                className={`radio-option ${visibility === 'PRIVATE' ? 'selected' : ''}`}
                onClick={() => setVisibility('PRIVATE')}
              >
                <input type="radio" checked={visibility === 'PRIVATE'} readOnly />
                Хувийн (зөвхөн би харна)
              </div>
              <div
                className={`radio-option ${visibility === 'PUBLIC' ? 'selected' : ''}`}
                onClick={() => setVisibility('PUBLIC')}
              >
                <input type="radio" checked={visibility === 'PUBLIC'} readOnly />
                Нийтэд нээлттэй
              </div>
            </div>
          </div>

          {uploading && (
            <div className="progress-bar">
              <div className="progress-fill" style={{ width: `${progress}%` }} />
            </div>
          )}

          <div style={{ marginTop: 24 }}>
            <button className="btn btn-primary btn-block" type="submit" disabled={uploading}>
              {uploading ? `Байршуулж байна… ${progress}%` : 'Байршуулах'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

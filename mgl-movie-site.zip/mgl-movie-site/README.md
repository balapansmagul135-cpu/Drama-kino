# MGL Movie — Кино/видео байршуулах платформ

Next.js (App Router) + PostgreSQL (Prisma) + NextAuth дээр суурилсан, өөрийн кино/видео
контентоо байршуулж, нэвтэрч удирддаг бүрэн ажилладаг вэб сайт.

## Боломжууд

- **Нэвтрэх / Бүртгүүлэх** — имэйл, нууц үгээр (нууц үг bcrypt-ээр хэшлэгдэж хадгалагдана)
- **Кино байршуулах** — mp4 / webm / mov / mkv файл, ахиц харуулсан upload
- **Хувийн / Нийтэд нээлттэй** горим — өөрийн видеог хэн харахыг сонгоно
- **Миний кино** — өөрийн байршуулсан бүх видеог удирдах, устгах
- **Нүүр хуудас** — нийтэд нээлттэй бүх видеог жагсаана

## 1. Урьдчилсан шаардлага

- Node.js 18+
- PostgreSQL өгөгдлийн сан (локал эсвэл Supabase / Railway / Neon зэрэг үнэгүй cloud сонголт)

## 2. Суулгах

```bash
npm install
```

## 3. Тохиргоо (.env)

`.env.example` файлыг хуулж `.env` нэрээр хадгал:

```bash
cp .env.example .env
```

Дараа нь дараах утгуудыг бөглөнө:

- `DATABASE_URL` — PostgreSQL холболтын мөр
- `NEXTAUTH_SECRET` — `openssl rand -base64 32` командаар үүсгэнэ
- `NEXTAUTH_URL` — локал дээр `http://localhost:3000`

## 4. Өгөгдлийн сан үүсгэх

```bash
npm run db:push
```

Энэ нь `prisma/schema.prisma` дахь `User` болон `Video` хүснэгтүүдийг таны
PostgreSQL дээр үүсгэнэ.

## 5. Локал дээр ажиллуулах

```bash
npm run dev
```

`http://localhost:3000` дээр нээгдэнэ.

## 6. Прод руу гаргах (deploy)

Хамгийн хялбар нь **Vercel** дээр байршуулах (Next.js-ийг өөрсдөө хийсэн компани):

1. Кодоо GitHub-д push хийнэ
2. Vercel дээр repo-гоо холбоно
3. Environment variables хэсэгт `.env`-ийн утгуудыг оруулна
4. Deploy дарна

⚠️ **Чухал анхаарах зүйл:** Vercel зэрэг serverless орчинд файл систем түр зуурын (ephemeral)
байдаг тул `public/uploads/videos`-д хадгалсан видео файлууд алга болж болзошгүй. Прод
орчинд заавал видеог **Cloudflare R2**, **AWS S3** зэрэг object storage руу хадгалахаар
`app/api/videos/route.ts` доторх файл бичих хэсгийг сольж ашиглана уу (S3-compatible API
ашигладаг тул кодны өөрчлөлт бага байх болно). Эсвэл VPS/Dedicated server дээр байршуулж,
локал storage-аа үргэлжлүүлж ашиглаж болно.

## 7. Аюулгүй байдлын тэмдэглэл

- Нууц үгс bcrypt-ээр хэшлэгдэж хадгалагдана, хэзээ ч plain text хэлбэрээр хадгалагдахгүй
- Хувийн видеог зөвхөн эзэмшигч нь үзэх боломжтой (server-side эрх шалгалттай)
- Видео устгах, upload хийх бүх үйлдэл нэвтэрсэн хэрэглэгчид л зөвшөөрөгдөнө
- Upload хийх файлын төрөл (зөвхөн видео формат) болон хэмжээ (`MAX_UPLOAD_SIZE_MB`)
  хязгаарлагдсан

## 8. Дараагийн сайжруулалт хийж болох зүйлс

- Видео thumbnail автоматаар үүсгэх (жишээ нь ffmpeg ашиглан)
- Видео хайлт, ангилал (жанр)-аар шүүх
- Видео үзсэн тоо, лайк/сэтгэгдэл
- Cloud storage (S3/R2) руу шууд шилжүүлэх интеграц
- Имэйл баталгаажуулалт, нууц үг сэргээх урсгал

## Файлын бүтэц

```
app/
  page.tsx                    — Нүүр хуудас
  login/page.tsx              — Нэвтрэх
  register/page.tsx           — Бүртгүүлэх
  my-movies/page.tsx          — Миний кино
  upload/page.tsx             — Кино байршуулах
  watch/[id]/page.tsx         — Видео үзэх
  api/auth/[...nextauth]/     — NextAuth handler
  api/auth/register/          — Бүртгэлийн API
  api/videos/                 — Видео CRUD API
components/
  Navbar.tsx, VideoCard.tsx, Providers.tsx
lib/
  prisma.ts, auth.ts
prisma/
  schema.prisma                — Өгөгдлийн сангийн схем
```

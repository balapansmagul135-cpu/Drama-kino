'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useSession, signOut } from 'next-auth/react';

export default function Navbar() {
  const pathname = usePathname();
  const { data: session, status } = useSession();

  const isActive = (href: string) => pathname === href;

  return (
    <header className="navbar">
      <div className="container navbar-inner">
        <Link href="/" className="brand">
          <span className="brand-mark" />
          MGL Movie
        </Link>

        <nav className="nav-links">
          <Link href="/" className={isActive('/') ? 'active' : ''}>
            Нүүр
          </Link>

          {status === 'authenticated' && (
            <Link href="/my-movies" className={isActive('/my-movies') ? 'active' : ''}>
              Миний кино
            </Link>
          )}

          {status === 'authenticated' ? (
            <>
              <Link href="/upload" className={isActive('/upload') ? 'active' : ''}>
                Байршуулах
              </Link>
              <a
                onClick={() => signOut({ callbackUrl: '/' })}
                style={{ cursor: 'pointer' }}
              >
                Гарах ({session.user?.name})
              </a>
            </>
          ) : (
            status !== 'loading' && (
              <Link href="/login" className="nav-cta">
                Нэвтрэх
              </Link>
            )
          )}
        </nav>
      </div>
    </header>
  );
}

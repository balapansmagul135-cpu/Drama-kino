import Link from 'next/link';

type VideoCardProps = {
  id: string;
  title: string;
  ownerName?: string;
  visibility: 'PUBLIC' | 'PRIVATE';
  showBadge?: boolean;
  createdAt: string;
};

export default function VideoCard({ id, title, ownerName, visibility, showBadge, createdAt }: VideoCardProps) {
  const date = new Date(createdAt).toLocaleDateString('mn-MN');

  return (
    <Link href={`/watch/${id}`} className="poster-card">
      <div className="poster-frame">
        {showBadge && (
          <span className={`poster-badge ${visibility === 'PUBLIC' ? 'public' : ''}`}>
            {visibility === 'PUBLIC' ? 'Нийтэд' : 'Хувийн'}
          </span>
        )}
        <div className="poster-placeholder">{title}</div>
      </div>
      <div className="poster-title">{title}</div>
      <div className="poster-meta">
        {ownerName ? `${ownerName} · ` : ''}
        {date}
      </div>
    </Link>
  );
}
